package com.cts.hibername.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Employee
{
	@Id
    private int empId;
	
	@Column(name="emp_name")
    private String empName;
	private String desg;
	
	
    public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDesg() {
		return desg;
	}
	public void setDesg(String desg) {
		this.desg = desg;
	}
	public Employee() {
		
	}
	public Employee(int empId, String empName, String desg) {
	
		this.empId = empId;
		this.empName = empName;
		this.desg = desg;
	}
	
	
    
}
