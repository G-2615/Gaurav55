package com.cts.hibername.hibernate;

import java.io.Serializable;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

public class Testhibernate {

	public static void main(String[] args) {

		/*
		 * SessionFactory sessionfactory = config.buildSessionFactory(); Session session
		 * = sessionfactory.openSession();
		 */

		// CREATE And UPDATE

		
		 Configuration configuration = new Configuration().configure();
		  StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
		  .applySettings(configuration.getProperties());
		 
		  SessionFactory factory = configuration.buildSessionFactory(builder.build());
		  
		  Session session = factory.openSession();
		  
		 Employee employee = new Employee(1002,"Gaurav","PAT");
		  session.beginTransaction(); Serializable o = session.save(employee);
		  employee.setDesg("AT"); employee.setEmpName("Sourabh");
		 session.getTransaction().commit(); System.out.println(o);
		 
		/*
		 * Configuration configuration = new Configuration().configure();
		 * StandardServiceRegistryBuilder builder = new StandardServiceRegistryBuilder()
		 * .applySettings(configuration.getProperties());
		 * 
		 * SessionFactory factory = configuration.buildSessionFactory(builder.build());
		 * 
		 * Session session = factory.openSession(); Employee employee = (Employee)
		 * session.get(Employee.class, new Long(2)); session.beginTransaction();
		 * session.evict(employee); session.getTransaction().commit(); //
		 * System.out.println(o);
		 */
	}

}
