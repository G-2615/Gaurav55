package com.egg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.PurchaseRepository;
import com.egg.dao.TransactionRepository;
import com.egg.model.PurchaseHistory;

/*//import com.cts.main.entities.PurchaseHistory;
//import com.cts.main.repository.PurchaseRepository;
//import com.cts.main.repository.TransactionRepository;
*/
@Service
public class PurchaseServices {
	
	@Autowired
	private PurchaseRepository purRepository;
	
	@Autowired
	private TransactionRepository transRepository;
	
	public PurchaseHistory addPurHistory(PurchaseHistory purHis) {
		
		return purRepository.save(purHis);
	}

}
