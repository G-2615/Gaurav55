package com.egg.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class TransactionHistory {
	
	@Id
	@GeneratedValue
	private int transaction_id;
	
	@ManyToOne
	@JoinColumn(name="buyer_Id")
	private UserInfo user;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateTime;
	private Double amount;
	private String transaction_Type;
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public UserInfo getUser() {
		return user;
	}
	public void setUser(UserInfo user) {
		this.user = user;
	}
	public LocalDate getDateTime() {
		return dateTime;
	}
	public void setDateTime(LocalDate dateTime) {
		this.dateTime = dateTime;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getTransaction_Type() {
		return transaction_Type;
	}
	public void setTransaction_Type(String transaction_Type) {
		this.transaction_Type = transaction_Type;
	}
	public TransactionHistory(int transaction_id, UserInfo user, LocalDate dateTime, Double amount,
			String transaction_Type) {
		super();
		this.transaction_id = transaction_id;
		this.user = user;
		this.dateTime = dateTime;
		this.amount = amount;
		this.transaction_Type = transaction_Type;
	}
	public TransactionHistory() {
		super();
	}
	@Override
	public String toString() {
		return "TransactionHistory [transaction_id=" + transaction_id + ", user=" + user + ", dateTime=" + dateTime
				+ ", amount=" + amount + ", transaction_Type=" + transaction_Type + "]";
	}
	
	
	

}
