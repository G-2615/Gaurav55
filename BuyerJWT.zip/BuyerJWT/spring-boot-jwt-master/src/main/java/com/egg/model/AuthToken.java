package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
    private int buyer_Id;

    public AuthToken(){

    }

    public AuthToken(String token, String username, int buyer_Id){
        this.token = token;
        this.username = username;
        this.buyer_Id = buyer_Id;
    }

    public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

	public int getBuyer_Id() {
		return buyer_Id;
	}

	public void setBuyer_Id(int buyer_Id) {
		this.buyer_Id = buyer_Id;
	}
    
}
