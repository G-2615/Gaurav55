import { Component, OnInit, Input } from '@angular/core';
import { Itemsearch1 } from '../Item';
import { cartitems } from '../cart';
import { SearchService} from '../newservice';

@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {

  cart: cartitems;
  carts: cartitems;


  constructor(private dataService : SearchService) { }
  
  @Input() items:Itemsearch1 = new Itemsearch1();
  ngOnInit(): void {
  }
  addtocart(){
    this.cart = new cartitems();
    this.cart.item_Id = this.items.i_Id;
    //this.cartitem.cartitem_Id=5;
    this.cart.item_price = this.items.item_Price;
    this.cart.quantity = 1;

    this.dataService.additemstocart(this.cart).subscribe(cartitems=>this.carts=cartitems);


  }

}
