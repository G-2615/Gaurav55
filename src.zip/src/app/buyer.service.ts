import { Injectable } from '@angular/core';
import {cartitems} from './cart';
import { HttpClient } from '@angular/common/http';
import {Observable}  from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  private baseUrl4 = 'http://localhost:8082/7/allitems';
  private baseUrl1 = 'http://localhost:8082/adduser';
  private baseUrl2 = 'http://localhost:8082';
  private baseUrl3 = 'http://localhost:8082';

  constructor(private http:HttpClient) { }


  getallItems():Observable<any>
  { 
    console.log("In Service");
    return this.http.get(`${this.baseUrl4}`);
  }

  buyersign(BI:object): Observable <any>
  
  {
      console.log("BI");
      console.log(BI);
      return this.http.post(`${this.baseUrl1}`,BI);
  }
  updatecartitem(cartitems:object,cart_Id:number): Observable<any>
  {
      console.log("update quantity");
      return this.http.put(`${this.baseUrl2}/${cart_Id}/update`,cartitems);
  }
  deletecartitems( cart_Id:number){
      console.log("delete in service");
      return this.http.delete(`${this.baseUrl3}/${cart_Id}/deletebyID`);
  }
}
