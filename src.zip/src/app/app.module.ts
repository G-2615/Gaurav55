import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { GetallitemsComponent } from './getallitems/getallitems.component';
import {BuyerService} from './buyer.service';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
//import { EmployeeComponent } from './employee.component';
//import { PpComponent } from './pp/pp.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
@NgModule({
  declarations: [
    AppComponent, GetallitemsComponent,BuyersignupComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [BuyerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
