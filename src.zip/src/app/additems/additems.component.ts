import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from '../newservice';
import { Itemsearch1 } from '../Item';
//import { SearchService } from '../newservice';
@Component({
  selector: 'app-additems',
  templateUrl: './additems.component.html',
  styleUrls: ['./additems.component.css']
})
export class AdditemsComponent implements OnInit {

  item_Name:String;
  item_Price:number;
  item_Desc:String;
  remarks:String;
  deleteitems: number;
  @Input() items: Itemsearch1 = new Itemsearch1();
  stock_Number: number;


  constructor(private dataService : SearchService) { }

  ngOnInit(): void {
  }

  additems(){
    this.items.item_Name = this.item_Name;
    this.items.item_Price = this.item_Price;
    this.items.item_Desc = this.item_Desc;
    this.items.remarks = this.remarks;
    this.items.stock_Number = this.stock_Number;
    console.log("in add item.ts");
    console.log(this.items);
    this.dataService.additems(this.items).subscribe(Itemsearch1=>this.items=Itemsearch1)
  }

  deleteitem(){
    console.log("in .ts file ");
    this.dataService.deleteitem(this.deleteitems).subscribe(Itemsearch1=>this.items=Itemsearch1)
  }

  updateitem(){
    this.items.item_Name = this.item_Name;
    this.items.item_Price = this.item_Price;
    this.items.item_Desc = this.item_Desc;
    this.items.remarks = this.remarks;
    this.items.stock_Number = this.stock_Number;
    this.dataService.updateitems(this.items).subscribe(Itemsearch1=>this.items=Itemsearch1)

  }

}
