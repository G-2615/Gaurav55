import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {GetallitemsComponent} from './getallitems/getallitems.component';
import {BuyersignupComponent} from './buyersignup/buyersignup.component';

const routes: Routes = [
  {path:'getallitems', component:GetallitemsComponent},
  {path:'buyersign', component:BuyersignupComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
