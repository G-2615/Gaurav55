import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AdditemsComponent} from './additems/additems.component';
import {ItemDetailsComponent} from './item-details/item-details.component';

const routes: Routes = [
  {path:'additems', component:AdditemsComponent},
  {path:'getallitems' ,component:ItemDetailsComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
