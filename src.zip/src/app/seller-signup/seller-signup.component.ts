/*import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-signup',
  templateUrl: './seller-signup.component.html',
  styleUrls: ['./seller-signup.component.css']
})
export class SellerSignupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
*/