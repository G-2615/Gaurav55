import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetallitemsComponent } from './getallitems.component';

describe('GetallitemsComponent', () => {
  let component: GetallitemsComponent;
  let fixture: ComponentFixture<GetallitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetallitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetallitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
