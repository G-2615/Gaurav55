import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
//import {ApiService} from "../service/api.service";
import {SearchService} from '../newservice';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:String;
  password:String;
  constructor(private router: Router, private dataService :SearchService){}

  login(){
    console.log("method log in ");
    const loginPayload = {
      username:this.username,
      password:this.password
    }
    this.dataService.login(loginPayload).subscribe(data=>{
      debugger;
      if(data.token !==null){
        alert("Success");
        console.log("if condition");
        window.localStorage.setItem('token',data.token);
        console.log("data.token");
        this.router.navigate(['navigation']);

      }else{
        alert("galat password");
      }
    });
  }
    ngOnInit(): void  {
  }
}
  

  
   
  


