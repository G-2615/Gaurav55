import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SearchService } from '../newservice';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  invalidLogin: boolean = false;
  constructor(private formBuilder: FormBuilder, private router: Router, private apiService:SearchService ) { }
  ngOnInit(): void {

    window.localStorage.removeItem('token');
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      seller_Password: ['', Validators.required]
    });
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }
    
    const loginPayload = {
      username: this.loginForm.controls.username.value,
      password: this.loginForm.controls.seller_Password.value
    }
    this.apiService.login(loginPayload).subscribe(data => {
      debugger;
      
      if(data.result.token !== null) {
        window.localStorage.setItem('token', data.result.token);
        window.localStorage.setItem('username', data.result.username);
        window.localStorage.setItem('seller_Id', data.result.seller_Id);
        this.router.navigate(['additems']);
        
      }else {
        this.invalidLogin = true;
        alert(data.message);
      }
    });
  }

}
