export class info {

    username:string;
    seller_password:string;
    seller_companyname:string;
    seller_Companyname:string;
	seller_GSTIN:string;
	seller_Companydesc:string;
	seller_Postaladdress:string;
    seller_Emailid:string;
	seller_contactnum:number;
	seller_Website:string;   
}