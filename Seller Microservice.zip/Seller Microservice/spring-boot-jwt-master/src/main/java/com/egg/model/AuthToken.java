package com.egg.model;

public class AuthToken {

    private String token;
    private String username;
    private int seller_Id;

    public AuthToken(){

    }

    public AuthToken(String token, String username,int seller_Id ){
        this.token = token;
        this.username = username;
        this.seller_Id = seller_Id;
    }

    public AuthToken(String token){
        this.token = token;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

	public int getSeller_Id() {
		return seller_Id;
	}

	public void setSeller_Id(int seller_Id) {
		this.seller_Id = seller_Id;
	}
    
    
}
