package com.egg.service;

import java.net.Inet4Address;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.ItemRepository;
import com.egg.dao.SellerRepository;
import com.egg.model.ItemSearch;
import com.egg.model.Items;
import com.egg.model.SellerInfo;


/*import com.cts.seller.Repository.ItemRepository;
import com.cts.seller.Repository.SellerRepository;

import com.cts.seller.entities.Category;
import com.cts.seller.entities.ItemSearch;
import com.cts.seller.entities.Items;
import com.cts.seller.entities.SellerInfo;
import com.cts.seller.entities.SubCategory;*/

@Service
public class ItemServices {
	
	@Autowired 
	private ItemRepository itemRepo;
	
	@Autowired
    private SellerRepository sellerRepo;
	
	
	

	public Items add(Items items, Integer seller_Id  ) {
		System.out.println("he");
		Optional<SellerInfo> sellerinfo = sellerRepo.findById(seller_Id);
		items.setSeller_Id(sellerinfo.get());
		return itemRepo.save(items);		
	}




	public List<Items> getallItems(Integer seller_Id) {
		
			return itemRepo.findBySeller_Id(seller_Id);
		
	}




	public Items update(Items items, Integer i_Id) {
		Optional<Items> oldItem = itemRepo.findById(i_Id);
		if(oldItem.isPresent()) {
			Items updatedItem = oldItem.get();
			updatedItem.setStock_Number(items.getStock_Number());
			updatedItem.setCategory(items.getCategory());
			updatedItem.setItem_Desc(items.getItem_Desc());
			updatedItem.setItem_Name(items.getItem_Name());
			updatedItem.setRemarks(items.getRemarks());
			updatedItem.setSeller_Id(items.getSeller_Id());
		//	updatedItem.setStock(items.getStock());
			updatedItem.setSubCategory(items.getSubCategory());
			return itemRepo.save(updatedItem);
		}
		return null;
	}




	public List<Items> searchItem(ItemSearch itemSearch) {
		System.out.println(itemSearch);
		return itemRepo.finditem(itemSearch.getItemname().toLowerCase());
	}




	public void itemDelete(Integer seller_Id, Integer i_Id) {
		
		itemRepo.deleteById(seller_Id,i_Id);
	}
	
	
}


