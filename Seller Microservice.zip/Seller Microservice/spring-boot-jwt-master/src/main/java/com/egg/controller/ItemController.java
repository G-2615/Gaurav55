package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.ItemSearch;
import com.egg.model.Items;
import com.egg.service.ItemServices;

//import com.cts.seller.entities.ItemSearch;
//import com.cts.seller.entities.Items;
//import com.cts.seller.services.ItemServices;

@CrossOrigin(origins="*")      //we can use it with method as well as class
@RestController
public class ItemController {
	
	@Autowired
	private ItemServices itemServices;
	
	@RequestMapping(value="/{seller_Id}/addItem",method=RequestMethod.POST, produces="application/json")
	public Items addItem(@PathVariable("seller_Id") Integer seller_Id,@RequestBody Items items) {
		System.out.println(seller_Id);
		return itemServices.add(items,seller_Id);
		
	}
	
	@RequestMapping(value="/{seller_Id}/getallitems",method=RequestMethod.GET, produces="application/json")
	public List<Items>getall(@PathVariable(value="seller_Id") Integer seller_Id){
		
		List<Items>getallItems=itemServices.getallItems(seller_Id);
    	return getallItems;
	}
	
	@RequestMapping(value="/{i_Id}/updateitem",method=RequestMethod.PUT, produces="application/json")
	public Items updateItems(/*@PathVariable(value="seller_Id") Integer seller_Id,*/@PathVariable(value="i_Id") Integer i_Id, @RequestBody Items items) {
		  
		  return itemServices.update(items,/*seller_Id*/i_Id);
		  }
	@RequestMapping(value="/search", method=RequestMethod.POST, produces= "application/json")
		
		public List<Items>searchItem(@RequestBody ItemSearch itemSearch){
		System.out.println(itemServices.searchItem(itemSearch));
		return itemServices.searchItem(itemSearch);
	}
	
	@RequestMapping(value="/{seller_Id}/{i_Id}/deleteitem", method=RequestMethod.DELETE, produces="application/json" )
		public void itemDelete(@PathVariable("seller_Id") Integer seller_Id, @PathVariable("i_Id") Integer i_Id) {
		itemServices.itemDelete(seller_Id,i_Id);
	}
	
/*
 * @RequestMapping(value="/Search", method=RequestMethod.GET,
 * produces="application/json") public List<Items>searchAll(@RequestBody Search
 * searchitem); return itemServices.SearchAll(searchitem); }
 */
}
