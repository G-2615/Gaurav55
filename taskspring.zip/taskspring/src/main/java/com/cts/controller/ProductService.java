package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	
	@Autowired
	ProductDao pDao;
	
	//ADDING PRODUCT
	
	public int addProduct(Product product) {
		
		return pDao.addProduct(product);
	}
	
public Product getById(int prodId) {
		
		return pDao.getById(prodId);
	}

	
	 public int deleteProduct(int prodId) {
	 
	  return pDao.deleteProduct(prodId);
	 
	  }
	 

/*	public int deleteAllProduct() {
		// TODO Auto-generated method stub
		return pDao.deleteAllProduct();
	}
*/
	
		public int updateProduct(Product product) {
			
			return pDao.updateProduct(product);
		}

	/*
	 * public int getAll(int prodId) {
	 * 
	 * return pDao.getAll(Product); }
	 */
		
	}

