package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
	
	@Autowired
	ProductDao pDao;
	
	//ADDING PRODUCT
	
	public int addProduct(Product product) {
		
		return pDao.addProduct(product);
	}
	
public Product getById(int prodId) {
		
		return pDao.getById(prodId);
	}
	

}
