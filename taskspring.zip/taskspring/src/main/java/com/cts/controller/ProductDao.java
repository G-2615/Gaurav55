package com.cts.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	//SETTER FOR JDBC TEMPLATE
	

	//ADDING PRODUCT
	
	public int addProduct(Product product) {
		
		jdbc = new JdbcTemplate(ds);
		int status = jdbc.update("INSERT INTO product VALUES(?,?,?,?)", new Object[] {product.getProdId(),product.getProdName(),product.getProdQuantity(),product.getProdPrice()});
		System.out.println(status);
		return product.getProdId();
		
	}
	
	//forID
	public Product getById(int prodId) {
		jdbc = new JdbcTemplate(ds);
	//	String sql = "SELECT * FROM product WHERE id=?";
		Product product = (Product)jdbc.queryForObject("SELECT * FROM product WHERE prodId=?", 
				new Object[] {prodId},

				new RowMapper<Product>() {
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product product = new Product();

				product.setProdId(rs.getInt(1));
				product.setProdName(rs.getString(2));
				product.setProdPrice(rs.getFloat(3));
				product.setProdQuantity(rs.getInt(4));
				

				return product;
			}

		});
		return product;
	}
	
	
	 public int deleteProduct(int prodId) { 
		 jdbc = new JdbcTemplate(ds);
	 int count = jdbc.update("DELETE FROM product WHERE prodId=?", new Object[]
	 {prodId}); return count;
	 
	  }
	
	
         public int updateProduct(Product product) {
			jdbc = new JdbcTemplate(ds);
			String sql = "UPDATE product SET prodName=?, prodQuantity=?, prodPrice=? WHERE prodId =?";
			int count = jdbc.update(sql,new Object[] 
					{product.getProdName(),product.getProdQuantity(),product.getProdPrice(),product.getProdId()});
			return count; 
			}
}

/*
 * public int getAll(int product) {
 * 
 * jdbc = new JdbcTemplate(ds); int c = jdbc.update("SELECT * FROM product", new
 * Object[]{product}, new RowMapper<Product>() { public Product mapRow(ResultSet
 * rs, int rowNum) throws SQLException {
 * 
 * Product product = new Product();
 * 
 * product.setProdId(rs.getInt(1)); product.setProdName(rs.getString(2));
 * product.setProdPrice(rs.getFloat(3)); product.setProdQuantity(rs.getInt(4));
 * 
 * 
 * return product }
 * 
 * }); return product; }
 */

	

