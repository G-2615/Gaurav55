package com.cts.controller;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class ProductDao {
	@Autowired
	private DataSource ds;
	private JdbcTemplate jdbc;
	
	//SETTER FOR JDBC TEMPLATE
	
	public void setJdbc(JdbcTemplate jdbc) {
		
		this.jdbc = jdbc;
	}
	
	//ADDING PRODUCT
	
	public int addProduct(Product product) {
		
		jdbc = new JdbcTemplate(ds);
		int storedStatus = jdbc.update("INSERT INTO product VALUES(?,?,?,?)", new Object[] {product.getProdId(),product.getProdName(),product.getProdQuantity(),product.getProdPrice()});
		System.out.println(storedStatus);
		return product.getProdId();
		
	}
	
	//GETBYID
	public Product getById(int prodId) {
		jdbc = new JdbcTemplate(ds);
		String sql = "SELECT * FROM product WHERE prod_id=?";
		Product product = (Product)jdbc.queryForObject(sql, new Object[] {prodId},

				new RowMapper<Product>() {
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {

				Product product = new Product();

				product.setProdId(rs.getInt(1));
				product.setProdName(rs.getString(2));
				product.setProdQuantity(rs.getInt(3));
				product.setProdPrice(rs.getFloat(4));

				return product;
			}

		});
		return product;
	}
	
	
	
	
	
	

	
}
