package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserInterface{
	
	@Autowired
	ProductService pServ;

	
	@RequestMapping(value="/add",method=RequestMethod.POST,produces="application/json")
	public int addProduct(@RequestBody Product product) {
		
		return pServ.addProduct(product);
	}
	@RequestMapping(value="/",method=RequestMethod.GET)
	
	public String Displaymethod() {
		
		return "index";
}
	@RequestMapping(value="/admin",method=RequestMethod.GET)
	public String Showadmin(ModelMap modelObj) {
		
		modelObj.addAttribute("Welcome", "Admin Comtrol Panel");
		modelObj.addAttribute("messageObj", "This Page Demonstrates How To Use Spring Security!");
		
		return "adminab";
	}
	
	/*
	 * @RequestMapping(value="/getall", method=RequestMethod.GET,
	 * produces="application/json") public int getAll(@RequestBody Product product)
	 * { return pServ.getAll(product); }
	 */
	
	
	//GETBYIDs
	@RequestMapping(value="/getbyid/{prodId}",method=RequestMethod.GET)
	public /*ResponseEntity<Product>*/Product getById(@PathVariable("prodId") int prodId) {
		//Product product = pServ.getById(prodId);
		/*if(product == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	}*/
		return pServ.getById(prodId);

}
	//Delete
	
	  @RequestMapping(value="/delete/{prodId}",method = RequestMethod.DELETE)
	 public ResponseEntity<Product> deleteProduct(@PathVariable("prodId") int
	  prodId){ HttpHeaders headers = new HttpHeaders(); Product product =
	  pServ.getById(prodId); 
	  if(product == null) { return new
	    ResponseEntity<Product>(HttpStatus.NOT_FOUND); 
	  }
	    pServ.deleteProduct(prodId); headers.add("Product Deleted - ",
	  String.valueOf(prodId));
	  return new  ResponseEntity<Product>(product,headers,HttpStatus.NO_CONTENT); }
	 
		/*@RequestMapping(value = "/product/", method = RequestMethod.DELETE)
	    public ResponseEntity<Product> deleteAllUsers() {
	        System.out.println("Deleting All Users");
		}*/
	 
	       // pServ.deleteAllProduct();
	       // return new ResponseEntity<Product>(HttpStatus.NO_CONTENT); }


		@RequestMapping(value="/up/{prodId}",method=RequestMethod.PUT, produces="application/json")
		public ResponseEntity<Product> updateProduct(@PathVariable("prodId") int prodId, @RequestBody Product product){
			HttpHeaders headers = new HttpHeaders();
			Product isProduct = pServ.getById(prodId);
			if(isProduct == null) {
				return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
			}
			else if (product == null) {
				return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
			}
			pServ.updateProduct(product);
			headers.add("Product Updated - ", String.valueOf(prodId));
			return new ResponseEntity<Product>(product,headers,HttpStatus.OK);
		}
		
		
			
}
