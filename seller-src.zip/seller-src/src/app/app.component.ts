import { Component } from '@angular/core';
import {SearchService} from './newservice';
import { Itemsearch1 } from './Item';
import {ItemList} from './Itemsearch';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  itemname:String;
  name:String;
  item: ItemList;
  itemlist:Itemsearch1[];

  constructor(private dataservice:SearchService){

    console.log("Constructor Invoked");

  }
  title = 'Basic-start';

  private SearchItems() {
    this.item = new ItemList;
    this.item.itemname=this.itemname;
    this.dataservice.getitem(this.item).subscribe(itemList=>this.itemlist=itemList);
}


met(){
this.SearchItems();
}

}
 
