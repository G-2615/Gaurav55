import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AdditemsComponent} from './additems/additems.component';
import {ItemDetailsComponent} from './item-details/item-details.component';
import { LoginComponent } from './login/login.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';


const routes: Routes = [
  {path:'additems', component:AdditemsComponent},
  { path: 'log', component: SellerloginComponent},
  { path: 'log1', component: LoginComponent},
  {path:'getallitems' ,component:ItemDetailsComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
