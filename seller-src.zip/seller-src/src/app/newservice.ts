import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Observable}  from 'rxjs';
import { Itemsearch1 } from './Item';
import { ApiResponse } from './api.response';


@Injectable({
  providedIn: 'root'
})
export class SearchService {

  private baseUrl =  'http://localhost:8800/search';
  private baseUrl1 = 'http://localhost:8800/1/addItem';
  private baseUrl2 = 'http://localhost:8800/23';
  private baseUrl3 = 'http://localhost:8083/56/updateitem';
  private baseUrl4 = 'http://localhost:8800/Buyer/1/addcartitem';
  private baseUrl5 = 'http://localhost:8800/token/generate-token';
  
  constructor(private http:HttpClient) { }

  additemstocart(add: object): Observable<any>{
    console.log("add to cart function");
    return this.http.post(`${this.baseUrl4}`,add);
  }

  getitem(ItemSear: Object): Observable<any> {
    return this.http.post(`${this.baseUrl}`,ItemSear);
  }

  additems(Itemsearch1:object): Observable <any>
  
  {
      console.log("Itemsearch1");
      console.log(Itemsearch1);
      return this.http.post(`${this.baseUrl1}`,Itemsearch1);
  }

  deleteitem(itemid: number) : Observable<any>

  {
    console.log("Itemsearch1");
    return this.http.delete(`${this.baseUrl2}/${itemid}/deleteitem`);
  }

  updateitems(Itemsearch1:object): Observable<any>
  {
    console.log(Itemsearch1);
    console.log("in service");

    return this.http.put(`${this.baseUrl3}`,Itemsearch1);
  }
  login(loginPayload): Observable<ApiResponse> {
  console.log(loginPayload);
    console.log("login service");
    return this.http.post<ApiResponse>('http://localhost:8800/'+ 'token/generate-token',loginPayload);

  }
  

  


}