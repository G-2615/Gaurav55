import { Component, OnInit, Input } from '@angular/core';
import { cartitems } from '../cart';
import {BuyerService} from '../buyer.service';

@Component({
  selector: 'app-getallitems',
  templateUrl: './getallitems.component.html',
  styleUrls: ['./getallitems.component.css']
})
export class GetallitemsComponent implements OnInit {

  cartitemss:cartitems[];
  //cartitemsss:cartitems;
  show:boolean = false;
  cart_Id: number;
  cart: cartitems;
  items: any;
  carts: any;
  constructor(private dataService : BuyerService ) { }
  @Input() cartitem = new cartitems();
  ngOnInit(): void { }
  getallcartitems(){
     this.show = true;
     this.dataService.getallItems().subscribe(cartitems=>this.cartitemss= cartitems);
  }
 

  addtocart(){
    this.cart = new cartitems();
    this.cart.item_Id = this.items.i_Id;
    //this.cartitem.cartitem_Id=5;
    this.cart.item_price = this.items.item_Price;
    this.cart.quantity = 1;

    this.dataService.additemstocart(this.cart).subscribe(cartitems=>this.carts=cartitems);


  }
  increment(items:cartitems)
  {
    console.log("incrementing");
    items.quantity=items.quantity+1;
    items.item_price = items.item_price*items.quantity;
    this.cart_Id=items.cart_Id;
    this.cartitem = new cartitems();
    this.cartitem.quantity=items.quantity;
    this.cartitem.item_price=items.item_price;
    this.dataService.updatecartitem(this.cartitem,this.cart_Id).subscribe(cartitems=>this.cartitemss=cartitems);
    console.log(items.item_price);
  }
  decrement(items:cartitems)
  {
    console.log("decrement");
    items.quantity=items.quantity-1;
    items.item_price = items.item_price*items.quantity;
    this.cart_Id=items.cart_Id;
    this.cartitem = new cartitems();
    this.cartitem.quantity=items.quantity;
    this.cartitem.item_price=items.item_price;
    this.dataService.updatecartitem(this.cartitem,this.cart_Id).subscribe(cartitems=>this.cartitemss=cartitems);

  }

  //buyer side

  deleteitems(items:cartitems){
    console.log("delete cart items in service");
    this.dataService.deletecartitems(items.cart_Id).subscribe();
  }

}
