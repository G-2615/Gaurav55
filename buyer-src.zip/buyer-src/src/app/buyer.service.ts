import { Injectable } from '@angular/core';
import {cartitems} from './cart';
import { HttpClient } from '@angular/common/http';
import {Observable}  from 'rxjs';
import { ApiResponse } from 'src/api.response';
@Injectable({
  providedIn: 'root'
})
export class BuyerService {

  private baseUrl4 = 'http://localhost:8811/7/allitems';
  private baseUrl1 = 'http://localhost:8811/adduser';
  private baseUrl2 = 'http://localhost:8082';
  private baseUrl3 = 'http://localhost:8082';
  private baseUrl =  'http://localhost:8800/search';
  private baseUrl7 = 'http://localhost:8800/Buyer/1/addcartitem';

  constructor(private http:HttpClient) { }


  getallItems():Observable<any>
   { 
    console.log("In Service");
     return this.http.get(`${this.baseUrl4}`);
   }

  buyersign(BI:object): Observable <any>
  
  {
      console.log("BI");
      console.log(BI);
      return this.http.post(`${this.baseUrl1}`,BI);
  }
  updatecartitem(cartitems:object,cart_Id:number): Observable<any>
  {
      console.log("update quantity");
      return this.http.put(`${this.baseUrl2}/${cart_Id}/update`,cartitems);
  }
  deletecartitems( cart_Id:number){
      console.log("delete in service");
      return this.http.delete(`${this.baseUrl3}/${cart_Id}/deletebyID`);
  }

  login(loginPayload): Observable<ApiResponse> {
      console.log(loginPayload);
      console.log("login service");
      return this.http.post<ApiResponse>('http://localhost:8811/'+ 'token/generate-token',loginPayload);
  
    }

    additemstocart(add: object): Observable<any>{
      console.log("add to cart function");
      return this.http.post(`${this.baseUrl7}`,add);
    }
    getitem(ItemSear: Object): Observable<any> {

      console.log("in serach ts");
      console.log(ItemSear);
      console.log(this.baseUrl);
      return this.http.post(`${this.baseUrl}`,ItemSear);
    }
  
}
