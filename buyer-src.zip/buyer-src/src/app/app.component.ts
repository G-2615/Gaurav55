import { Component } from '@angular/core';
import { BuyerService } from './buyer.service';
import { Itemsearch1 } from 'src/Item';
import { ItemList } from 'src/Itemsearch';
//import { User } from './users';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',           
  styleUrls: ['./app.component.css']
})

export class AppComponent { 

itemname:String;
name:String;
item: ItemList;
itemlist:Itemsearch1[];

constructor(private dataservice:BuyerService){

  console.log("Constructor Invoked");

}
title = 'Basic-start';

private SearchItems() {
  console.log("in serach ts");
  this.item = new ItemList;
  this.item.itemname=this.itemname;
  this.dataservice.getitem(this.item).subscribe(itemList=>this.itemlist=itemList);
}


met(){
this.SearchItems();
}

}


