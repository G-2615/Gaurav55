import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppComponent } from './app.component';
import { GetallitemsComponent } from './getallitems/getallitems.component';
import {BuyerService} from './buyer.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
//import { EmployeeComponent } from './employee.component';
//import { PpComponent } from './pp/pp.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { LoginComponent } from './login/login.component';
import { ViewcartComponent } from './viewcart/viewcart.component';
@NgModule({
  declarations: [
    AppComponent, GetallitemsComponent,BuyersignupComponent,LoginComponent, ViewcartComponent],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [BuyerService],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class AppModule { }
