package com.egg.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonFormat;


@Entity
public class PurchaseHistory {
	
	@Id
	@GeneratedValue
	private int ph_Id;
	
	@ManyToOne
	@JoinColumn(name="buyer_Id")
	private UserInfo user;
	
	@ManyToOne
	@JoinColumn(name="transaction_Id")
	private TransactionHistory th;
	
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate dateTime;
	
	private int itemPurchased;

	public int getPh_Id() {
		return ph_Id;
	}

	public void setPh_Id(int ph_Id) {
		this.ph_Id = ph_Id;
	}

	public UserInfo getUser() {
		return user;
	}

	public void setUser(UserInfo user) {
		this.user = user;
	}

	public TransactionHistory getTh() {
		return th;
	}

	public void setTh(TransactionHistory th) {
		this.th = th;
	}

	public LocalDate getDateTime() {
		return dateTime;
	}

	public void setDateTime(LocalDate dateTime) {
		this.dateTime = dateTime;
	}

	public int getItemPurchased() {
		return itemPurchased;
	}

	public void setItemPurchased(int itemPurchased) {
		this.itemPurchased = itemPurchased;
	}

	public PurchaseHistory(int ph_Id, UserInfo user, TransactionHistory th, LocalDate dateTime, int itemPurchased) {
		super();
		this.ph_Id = ph_Id;
		this.user = user;
		this.th = th;
		this.dateTime = dateTime;
		this.itemPurchased = itemPurchased;
	}

	public PurchaseHistory() {
		super();
	}
	
	
}