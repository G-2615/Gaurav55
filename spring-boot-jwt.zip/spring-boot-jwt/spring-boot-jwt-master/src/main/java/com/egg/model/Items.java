package com.egg.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ItemInfo")
public class Items {
	
	@Id
	@GeneratedValue
	private int i_Id;
	
	private String item_Name;
	
	private float item_Price;
	
	private String item_Desc;
	
	@ManyToOne
	private Category category;
	
	@ManyToOne
	private SubCategory subCategory;
	
	private String remarks;
	
	
	@ManyToOne
	private SellerInfo seller_Id;
	
	private int stock_Number;

	public int getI_Id() {
		return i_Id;
	}

	public void setI_Id(int i_Id) {
		this.i_Id = i_Id;
	}

	public String getItem_Name() {
		return item_Name;
	}

	public void setItem_Name(String item_Name) {
		this.item_Name = item_Name;
	}

	public float getItem_Price() {
		return item_Price;
	}

	public void setItem_Price(float item_Price) {
		this.item_Price = item_Price;
	}

	public String getItem_Desc() {
		return item_Desc;
	}

	public void setItem_Desc(String item_Desc) {
		this.item_Desc = item_Desc;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public SubCategory getSubCategory() {
		return subCategory;
	}

	public void setSubCategory(SubCategory subCategory) {
		this.subCategory = subCategory;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	

	public SellerInfo getSeller_Id() {
		return seller_Id;
	}

	public void setSeller_Id(SellerInfo seller_Id) {
		this.seller_Id = seller_Id;
	}

	public int getStock_Number() {
		return stock_Number;
	}

	public void setStock_Number(int stock_Number) {
		this.stock_Number = stock_Number;
	}

	public Items(int i_Id, String item_Name, float item_Price, String item_Desc, Category category,
			SubCategory subCategory, String remarks, SellerInfo seller_Id, int stock_Number) {
		super();
		this.i_Id = i_Id;
		this.item_Name = item_Name;
		this.item_Price = item_Price;
		this.item_Desc = item_Desc;
		this.category = category;
		this.subCategory = subCategory;
		this.remarks = remarks;
		this.seller_Id = seller_Id;
		this.stock_Number = stock_Number;
	}

	public Items() {
		super();
	}

	@Override
	public String toString() {
		return "Items [i_Id=" + i_Id + ", item_Name=" + item_Name + ", item_Price=" + item_Price + ", item_Desc="
				+ item_Desc + ", category=" + category + ", subCategory=" + subCategory + ", remarks=" + remarks
				+ ", seller_Id=" + seller_Id + ", stock_Number=" + stock_Number + "]";
	}
	
	
	
	
	
 

}
