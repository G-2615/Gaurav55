package com.egg.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerRepository;
import com.egg.model.User;
import com.egg.model.UserInfo;



@Service
public class BuyerServices implements UserDetailsService{
	
	@Autowired
	private BuyerRepository buyerRepository;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserInfo adduser(UserInfo user) {
		// TODO Auto-generated method stub
		user.setBuyer_password(bcryptEncoder.encode(user.getBuyer_password()));
		return buyerRepository.save(user);
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserInfo user = buyerRepository.findByusername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getBuyer_password(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public UserInfo findOne(String username) {
		return buyerRepository.findByusername(username); 
	}

		
	}


