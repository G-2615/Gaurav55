package com.egg.controller;

import java.util.List;
import java.util.Optional;

import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.CartItems;
import com.egg.service.CartServices;



@RestController
public class CartController {
	
	
	
	@Autowired
	private CartServices cartServices;
	
    @RequestMapping(value="Buyer/{buyer_Id}/addcartitem",method=RequestMethod.POST, produces="application/json")
	
	public CartItems addCart(@PathVariable(value="buyer_Id") Integer buyer_Id,@RequestBody CartItems cartItems) {
		Optional<CartItems>saveItem=cartServices.addtoCart(cartItems,buyer_Id);
		return saveItem.get();
		
	}
    
   @RequestMapping(value="/{buyer_Id}/allitems",method=RequestMethod.GET, produces="application/json")
    public List<CartItems>getall(@PathVariable(value="buyer_Id") Integer buyer_Id){
    	
    	List<CartItems>getallItems=cartServices.getallCartItems(buyer_Id);
    	return getallItems;
    }
   
   

	/*
	 * @RequestMapping(value="/{buyer_Id}/allitems",method=RequestMethod.PUT,
	 * produces="application/json") Public CartItems
	 * updateCart(@PathVariable(value="cart_Id") Integer cart_Id, @RequestBody
	 * CartItems cartItems) {
	 * 
	 * return cartServices.updateCart(cartItems,cart_Id); }
	 */
   @RequestMapping(value="/{cart_Id}/update",method=RequestMethod.PUT, produces="application/json")
   public CartItems updateCart(@PathVariable(value="cart_Id") Integer cart_Id, @RequestBody CartItems cartItems) {
	  
	  return cartServices.updateCart(cartItems,cart_Id);
	  }
   
   @RequestMapping(value="/{cart_Id}/deletebyID",method=RequestMethod.DELETE, produces="application/json")
   
   public String deleteItems(@PathVariable(value="cart_Id") Integer cart_Id ) {
   
    String s = cartServices.deleteID(cart_Id);
   
    return s;
   }
   
@RequestMapping(value="/{buyer_Id}/deleteAll",method=RequestMethod.DELETE, produces="application/json")
   
   public String emptyCart(@PathVariable(value="buyer_Id") Integer buyer_Id ) {
	
	String ss= cartServices.empty(buyer_Id);
	
	return ss;
}
/*
@RequestMapping(value="/{buyer_Id}/checkout", method=RequestMethod.POST, produces="application/json")
public String checkout(@PathVariable(value="buyer_Id") Integer buyer_Id) {
	return cartServices.emptycartItems(buyer_Id);
}*/
   
    


}
